# WebAssembly validation report

Validation date: 2026-10-10

Repository baseline: `88922f77219bdfda81e5d6bbaa38698e7bc864d5`

Branch: `codex/wasm-browser-port`

## Classification

| Check | Result |
| --- | --- |
| `NATIVE_BASELINE_PASS` | PASS |
| `WASM_BUILD_PASS` | PASS |
| `DUAL_KKT_PASS` | PASS |
| `NATIVE_WASM_EQUIVALENCE_PASS` | PASS |
| `BROWSER_SMOKE_PASS` | PASS |
| `MEMORY_LOOP_PASS` | PASS |

The original CMake project built before the WebAssembly changes and linked again after them in a Visual Studio x64 developer environment.  The separate 32-bit-index native comparison executable also solved the analytic SOCP.  The repository's `runecos` source is not a reproducible baseline runner in this checkout: it contains a pre-existing absolute input path, `D:\working\conf\Convert\data.dat`, which is not part of the repository.  The root Makefile also assumes POSIX `uname` and adds `-lrt` when invoked directly from this Windows shell.  These are classified as pre-existing legacy-runner/environment failures, not WebAssembly regressions.

## Toolchain and artifacts

- Emscripten: `6.0.2-git (7a2d97d627ff4945eae28847ce0387ac52b92c09)`
- LLVM/Clang: `23.1.3`
- Node.js: `v24.8.0`
- CMake: `4.3.1-msvc1`
- WebAssembly index width: 32 bits
- WebAssembly scalar width: 64 bits
- `dist-wasm/ecos.js`: 57,827 bytes, SHA-256 `0745ccc847515f620de7c3ac080c708dcfe35e08f77077b62213309fcf6064b5`
- `dist-wasm/ecos.wasm`: 102,184 bytes, SHA-256 `bdd1405bf8b70bb6d596173e8fb11f32ee45f1bf45b1577bb8910e802787f998`

The CMake 4.3.1 Emscripten platform file emits a shared-library support warning.  This adapter builds a static core and an executable JavaScript/WASM module, so that warning does not apply to either produced target.

## Analytic SOCP

Status: `optimal` (`0`)

Expected values:

```text
x = [5, 3, 4]
y = [-0.6, -0.8]
z = [1, -0.6, -0.8]
s = [5, 3, 4]
```

Native and WASM values (identical in this run):

```text
x = [4.999999996036806, 2.9999999999999973, 3.9999999999999964]
y = [-0.5999999935710228, -0.8000000045922173]
z = [1.0000000000049556, -0.5999999935710258, -0.8000000045922211]
s = [5.000000006527979, 2.9999999999999765, 4.000000000000023]
```

Native/WASM infinity-norm differences:

```text
x: 0
y: 0
z: 0
s: 0
```

The observed ECOS dual convention is `c + A' y + G' z = 0`, with dual objective `-(b' y + h' z)`.

Independent KKT checks:

```text
||Ax-b||inf             = 3.552713678800501e-15
||Gx+s-h||inf           = 1.0491173263460496e-8
||c+A'y+G'z||inf        = 4.955591492716849e-12
s'z                     = 7.470791096864104e-9
SOC s violation         = 0
SOC z violation         = 0
primal objective        = 4.999999996036806
dual objective          = 4.999999999081938
```

ECOS info:

```text
pcost   = 4.999999996036806
dcost   = 4.999999999081938
pres    = 4.0789826551153406e-10
dres    = 1.2955061073340497e-12
gap     = 7.48783657300578e-9
relgap  = 1.4975673148761278e-9
iter    = 5
```

## Additional tests

- Positive-orthant LP (`l > 0`, linear-cone `z`): PASS.
- No-equality SOCP (`p=0`, null A/b/y pointers): PASS.
- Primal-infeasible LP status propagation: PASS.
- Invalid dimensions, NaN, cone-row mismatch, CSC pointers, and row-index validation: PASS.

## Memory and performance

The analytic problem was solved once for first-call timing and then 100 consecutive times through the same module instance.

```text
heap before = 16908288 bytes
heap after  = 16908288 bytes
WASM first call = 2.9391 ms
WASM warm median = 0.04625 ms
native median = 0.01 ms
```

The timings are reference values from a small problem, not an optimization target.

## Browser smoke

The repository root was served from `http://127.0.0.1:8000`, and `wasm/demo/` was opened in a real browser.  The page displayed `ECOS WASM loaded`, `optimal`, the expected objective and complete `x/y/z/s` data, residuals, gap, and iteration count.  The browser warning/error console was empty.  There were no WASM load, uncaught exception, or invalid-memory-access errors.

## Scope and deployment

No ECOS interior-point, cone, preprocessing, or KKT algorithm source was modified.  No `blog_temp` or `LGR_Learning_prj` files were modified.  The generated files are ready for private/local integration testing, but public deployment remains gated on a GPL-3.0 corresponding-source distribution plan.
