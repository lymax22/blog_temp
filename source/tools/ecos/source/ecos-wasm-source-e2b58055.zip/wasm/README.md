# ECOS WebAssembly browser adapter

This directory adds a browser- and Node-compatible WebAssembly build around the existing continuous ECOS solver.  It does not reimplement ECOS or expose the layout of `pwork`; the C adapter creates a workspace, solves once, copies all requested data, and destroys the workspace before returning.

## Architecture

```text
JSON problem
  -> wasm/js/solver.js (validation, dense-to-CSC, memory ownership)
  -> ecos_wasm_solve_once() (stable flat C ABI)
  -> ECOS_setup / ECOS_solve / copy / ECOS_cleanup
  -> JSON result with x, y, z, s, status, and solver info
```

The build compiles continuous ECOS only.  LP and SOCP are the validated first-version scope; the schema passes `nex` through to ECOS, but exponential cones are not covered by this milestone's tests.  ECOS_BB, warm starts, workers, threads, and SIMD are outside this first browser port.  The compiled core uses 64-bit `double` values and 32-bit `int` indices, with `CTRLC=0`.  The native comparison executable is built from exactly the same continuous source list and index configuration.

## Requirements and Emscripten setup

- CMake 3.15 or newer
- Ninja
- Node.js 18 or newer
- a native C compiler (`gcc` on Windows for the comparison target)
- Emscripten 6.0.2 (the tested version; its LLVM 23 requirement matches the tested toolchain)

The most reproducible setup is an official emsdk checkout outside this repository, pinned to the tested version:

```powershell
git clone https://github.com/emscripten-core/emsdk.git D:\working\_tools\emsdk
D:\working\_tools\emsdk\emsdk.bat install 6.0.2
D:\working\_tools\emsdk\emsdk.bat activate 6.0.2
pwsh -File .\wasm\scripts\build.ps1 -EmsdkRoot D:\working\_tools\emsdk -EmscriptenVersion 6.0.2
```

The tested host used an existing D: MSYS2 installation of Emscripten 6.0.2 and Clang 23; `build.ps1` detects that layout as a local fallback.  It also accepts an emsdk installation through `-EmsdkRoot` or `EMSDK`.  Toolchains must not be copied into this repository.  If CMake and Ninja are provided by Visual Studio, `build.ps1` discovers their bundled paths automatically.

On macOS or Linux, clone emsdk to a tools directory, run `./emsdk install 6.0.2`, then `./emsdk activate 6.0.2`.  Set `EMSDK` to that checkout.

## Build and test

Windows:

```powershell
pwsh -File .\wasm\scripts\build.ps1
pwsh -File .\wasm\scripts\test.ps1 -SkipBuild
```

macOS/Linux:

```bash
EMSDK=/path/to/emsdk ./wasm/scripts/build.sh
./wasm/scripts/test.sh --skip-build
```

The one-command test script without `-SkipBuild`/`--skip-build` performs the build first.  A successful build creates:

```text
dist-wasm/ecos.js
dist-wasm/ecos.wasm
dist-wasm/manifest.json
```

`manifest.json` records the source commit, compiler, data widths, file sizes, and SHA-256 hashes.  `build-wasm/` and `dist-wasm/` are generated and ignored by Git.

The current browser target deliberately links at `-O0`: this milestone prioritizes numerical equivalence and lifecycle verification, and avoids coupling the deliverable to a particular Binaryen optimizer revision.  The ECOS C sources are still compiled with the normal CMake Release flags.  Optimization is intentionally deferred until after this correctness baseline.

## JavaScript API

```js
import { solveSocp } from "./wasm/js/solver.js";

const result = await solveSocp(problem);
```

`solveSocp` loads one shared Emscripten module lazily.  Each call owns and frees its input/output allocations.  It copies the output typed arrays into ordinary JavaScript arrays before freeing the WASM buffers.

The result shape is:

```js
{
  statusCode,
  status,
  primal: { x },
  dual: { y, z },
  slack: { s },
  info: { pcost, dcost, pres, dres, gap, relgap, pinfres, dinfres, iter }
}
```

Status names include `optimal`, `primal_infeasible`, `dual_infeasible`, `numerical_problem`, `max_iterations`, and `unknown`, plus explicit inaccurate variants.  Callers must inspect `status`; non-optimal codes are never rewritten as success.

### Problem schema

```js
{
  c: [/* n finite numbers */],
  G: {/* CSC, m by n */},
  h: [/* m finite numbers */],
  A: {/* optional CSC, p by n */},
  b: [/* p finite numbers; [] means no equalities */],
  cones: { l: 0, q: [3], nex: 0 }
}
```

CSC matrices use:

```js
{
  format: "csc",
  rows: m,
  cols: n,
  values: [...],
  colPointers: [0, /* monotonic */, values.length],
  rowIndices: [/* each in [0, rows) */]
}
```

Aliases `data/indptr/indices` and `pr/jc/ir` are accepted.  A logical row-major dense 2D array is also accepted and converted column-by-column to CSC.  The adapter rejects non-finite values, inconsistent dimensions, invalid indices, non-monotonic column pointers, and cone rows that do not satisfy:

```text
m = l + sum(q) + 3*nex
```

When `p=0`, omit `A` or provide a `0 x n` CSC matrix and use `b: []`.  The C call then receives null `A`, `b`, and `y` pointers.

## Variable and dual convention

ECOS solves the standard form

```text
minimize    c' x
subject to  A x = b
            G x + s = h,  s in K
```

- `x` is the primal decision vector.
- `y` is the equality multiplier.
- `z` is the multiplier in the dual cone.
- `s` is the conic slack.

This source tree uses stationarity `c + A' y + G' z = 0` and dual objective `-(b' y + h' z)`.  For the analytic test with `G=-I`, `u=(3,4)`, the native solver confirms `y=(-3/5,-4/5)` and `z=(1,-3/5,-4/5)`.

The flat C `info_out` layout is declared by named constants in `wrapper/ecos_wasm.h`:

```text
0 pcost, 1 dcost, 2 pres, 3 dres,
4 gap,   5 relgap, 6 pinfres, 7 dinfres
```

`iter` is written through a separate integer pointer.  No JavaScript code parses C struct padding.

## Verification

`test_dual_kkt.mjs` independently calculates `Ax-b`, `Gx+s-h`, stationarity, SOC membership, complementarity, and primal/dual objectives.  `test_basic.mjs` covers a positive-orthant LP, a no-equality SOCP with null/zero-length arrays, invalid inputs, and an infeasible LP.  `test_native_vs_wasm.mjs` compares every element of `x/y/z/s` and key solver statistics against the 32-bit-index native target.  `run_all.mjs` also solves the analytic problem 100 times after warm-up and verifies that the WASM heap does not grow.

## Browser smoke test

Serve the repository root; do not open the page via `file://`:

```powershell
python -m http.server 8000
```

Then open `http://localhost:8000/wasm/demo/`.  The page displays the load state, status, objective, `x/y/z/s`, residuals, gap, and iteration count.  The solver module itself has no DOM dependency and can later be wrapped by a WebMCP tool without changing its API.

## License and deployment note

The ECOS core in this repository is GPL-3.0.  This work only prepares and privately verifies a distributable WebAssembly artifact.  A future public deployment of `ecos.wasm` and its JavaScript loader must provide the corresponding source in a GPL-compliant way and preserve required notices.  Do not make this private repository public merely to deploy the binary.  No files in `blog_temp` or `LGR_Learning_prj` are touched by this work.
