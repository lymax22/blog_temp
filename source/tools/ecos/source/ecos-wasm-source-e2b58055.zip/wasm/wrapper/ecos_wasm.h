/*
 * Stable, one-shot C ABI for the ECOS WebAssembly adapter.
 *
 * ECOS itself remains the owner of its workspace.  All solution data is
 * copied to caller-owned buffers before ECOS_cleanup() is called.
 */
#ifndef ECOS_WASM_H
#define ECOS_WASM_H

#ifdef __cplusplus
extern "C" {
#endif

enum ecos_wasm_info_index {
    ECOS_WASM_INFO_PCOST = 0,
    ECOS_WASM_INFO_DCOST = 1,
    ECOS_WASM_INFO_PRES = 2,
    ECOS_WASM_INFO_DRES = 3,
    ECOS_WASM_INFO_GAP = 4,
    ECOS_WASM_INFO_RELGAP = 5,
    ECOS_WASM_INFO_PINFRES = 6,
    ECOS_WASM_INFO_DINFRES = 7,
    ECOS_WASM_INFO_LENGTH = 8
};

enum ecos_wasm_wrapper_status {
    ECOS_WASM_SETUP_FAILED = -100,
    ECOS_WASM_INVALID_ARGUMENT = -101
};

int ecos_wasm_solve_once(
    int n,
    int m,
    int p,
    int l,
    int ncones,
    const int* q,
    int nex,
    const double* Gpr,
    const int* Gjc,
    const int* Gir,
    const double* Apr,
    const int* Ajc,
    const int* Air,
    const double* c,
    const double* h,
    const double* b,
    double* x_out,
    double* y_out,
    double* z_out,
    double* s_out,
    double* info_out,
    int* iter_out);

#ifdef __cplusplus
}
#endif

#endif
