#include "ecos_wasm.h"

#include <stddef.h>
#include <string.h>

#include "ecos.h"

#ifdef __EMSCRIPTEN__
#include <emscripten/emscripten.h>
#define ECOS_WASM_EXPORT EMSCRIPTEN_KEEPALIVE
#else
#define ECOS_WASM_EXPORT
#endif

static int arguments_are_valid(
    int n,
    int m,
    int p,
    int l,
    int ncones,
    const int* q,
    int nex,
    const double* Gpr,
    const int* Gjc,
    const int* Gir,
    const double* Apr,
    const int* Ajc,
    const int* Air,
    const double* c,
    const double* h,
    const double* b,
    double* x_out,
    double* y_out,
    double* z_out,
    double* s_out,
    double* info_out,
    int* iter_out)
{
    int i;
    int cone_rows = l + 3 * nex;

    if (n <= 0 || m <= 0 || p < 0 || l < 0 || ncones < 0 || nex < 0) {
        return 0;
    }
    if (ncones > 0 && q == NULL) {
        return 0;
    }
    for (i = 0; i < ncones; ++i) {
        if (q[i] <= 0) {
            return 0;
        }
        cone_rows += q[i];
    }
    if (cone_rows != m) {
        return 0;
    }
    if (Gjc == NULL || c == NULL || h == NULL ||
        x_out == NULL || z_out == NULL || s_out == NULL || info_out == NULL ||
        iter_out == NULL) {
        return 0;
    }
    if (Gjc[n] > 0 && (Gpr == NULL || Gir == NULL)) {
        return 0;
    }
    if (p > 0 && (Ajc == NULL || b == NULL || y_out == NULL)) {
        return 0;
    }
    if (p > 0 && Ajc[n] > 0 && (Apr == NULL || Air == NULL)) {
        return 0;
    }
    return 1;
}

ECOS_WASM_EXPORT int ecos_wasm_solve_once(
    int n,
    int m,
    int p,
    int l,
    int ncones,
    const int* q,
    int nex,
    const double* Gpr,
    const int* Gjc,
    const int* Gir,
    const double* Apr,
    const int* Ajc,
    const int* Air,
    const double* c,
    const double* h,
    const double* b,
    double* x_out,
    double* y_out,
    double* z_out,
    double* s_out,
    double* info_out,
    int* iter_out)
{
    int exit_code;
    pwork* work;

    if (!arguments_are_valid(
            n, m, p, l, ncones, q, nex,
            Gpr, Gjc, Gir, Apr, Ajc, Air, c, h, b,
            x_out, y_out, z_out, s_out, info_out, iter_out)) {
        return ECOS_WASM_INVALID_ARGUMENT;
    }

    work = ECOS_setup(
        (idxint)n, (idxint)m, (idxint)p, (idxint)l, (idxint)ncones,
        (idxint*)q, (idxint)nex,
        (pfloat*)Gpr, (idxint*)Gjc, (idxint*)Gir,
        (pfloat*)Apr, (idxint*)Ajc, (idxint*)Air,
        (pfloat*)c, (pfloat*)h, (pfloat*)b);
    if (work == NULL) {
        return ECOS_WASM_SETUP_FAILED;
    }

    work->stgs->verbose = 0;
    exit_code = (int)ECOS_solve(work);

    memcpy(x_out, work->x, (size_t)n * sizeof(double));
    if (p > 0) {
        memcpy(y_out, work->y, (size_t)p * sizeof(double));
    }
    memcpy(z_out, work->z, (size_t)m * sizeof(double));
    memcpy(s_out, work->s, (size_t)m * sizeof(double));

    info_out[ECOS_WASM_INFO_PCOST] = work->info->pcost;
    info_out[ECOS_WASM_INFO_DCOST] = work->info->dcost;
    info_out[ECOS_WASM_INFO_PRES] = work->info->pres;
    info_out[ECOS_WASM_INFO_DRES] = work->info->dres;
    info_out[ECOS_WASM_INFO_GAP] = work->info->gap;
    info_out[ECOS_WASM_INFO_RELGAP] = work->info->relgap;
    info_out[ECOS_WASM_INFO_PINFRES] = work->info->pinfres;
    info_out[ECOS_WASM_INFO_DINFRES] = work->info->dinfres;
    iter_out[0] = (int)work->info->iter;

    ECOS_cleanup(work, 0);
    return exit_code;
}
