param(
    [string]$EmsdkRoot = $(if ($env:EMSDK) { $env:EMSDK } else { '' }),
    [string]$EmscriptenVersion = 'latest',
    [string]$CMakePath = '',
    [string]$NinjaPath = ''
)

$ErrorActionPreference = 'Stop'
$repositoryRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$wasmSource = Join-Path $repositoryRoot 'wasm'
$buildRoot = Join-Path $repositoryRoot 'build-wasm'
$wasmBuild = Join-Path $buildRoot 'wasm'
$nativeBuild = Join-Path $buildRoot 'native'
$distribution = Join-Path $repositoryRoot 'dist-wasm'
$env:EM_CACHE = Join-Path $buildRoot 'emcache'
$env:TEMP = Join-Path $buildRoot 'tmp'
$env:TMP = $env:TEMP
New-Item -ItemType Directory -Path $env:TEMP -Force | Out-Null

$emccCommand = Get-Command emcc -ErrorAction SilentlyContinue
$emcmakeCommand = Get-Command emcmake -ErrorAction SilentlyContinue
if (-not $emccCommand -or -not $emcmakeCommand) {
    $msysEmscripten = 'D:\software\msy\ucrt64\lib\emscripten'
    $msysEmcc = @('emcc.exe', 'emcc.ps1') | ForEach-Object { Join-Path $msysEmscripten $_ } | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
    $msysEmcmake = @('emcmake.exe', 'emcmake.ps1') | ForEach-Object { Join-Path $msysEmscripten $_ } | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
    if ($msysEmcc -and $msysEmcmake) {
        $hostPython = Get-Command python -ErrorAction SilentlyContinue
        $env:PATH = 'D:\software\msy\clang64\bin;D:\software\msy\ucrt64\bin;D:\software\msy\usr\bin;' + $env:PATH
        $env:EMSDK_NODE = 'D:\software\msy\ucrt64\bin\node.exe'
        $env:EMSDK_PYTHON = if ($hostPython) { $hostPython.Source } else { 'D:\software\msy\ucrt64\bin\python.exe' }
        $emccCommand = $msysEmcc
        $emcmakeCommand = $msysEmcmake
    } elseif ($EmsdkRoot -and (Test-Path -LiteralPath (Join-Path $EmsdkRoot 'emsdk.bat'))) {
        & (Join-Path $EmsdkRoot 'emsdk.bat') activate $EmscriptenVersion
        if ($LASTEXITCODE -ne 0) { throw 'emsdk activation failed' }
        & (Join-Path $EmsdkRoot 'emsdk_env.ps1')
        if ($LASTEXITCODE -ne 0) { throw 'emsdk environment setup failed' }
        $emccCommand = Get-Command emcc -ErrorAction Stop
        $emcmakeCommand = Get-Command emcmake -ErrorAction Stop
    } else {
        throw 'Emscripten was not found. Follow wasm/README.md to install it.'
    }
}

if (-not $CMakePath) {
    $cmakeCommand = Get-Command cmake -ErrorAction SilentlyContinue
    if ($cmakeCommand) {
        $CMakePath = $cmakeCommand.Source
    } else {
        $vswhere = 'C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe'
        if (Test-Path -LiteralPath $vswhere) {
            $vsRoot = & $vswhere -latest -products '*' -property installationPath
            $candidate = Join-Path $vsRoot 'Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe'
            if (Test-Path -LiteralPath $candidate) { $CMakePath = $candidate }
        }
    }
}
if (-not $CMakePath -or -not (Test-Path -LiteralPath $CMakePath)) { throw 'cmake was not found' }

if (-not $NinjaPath) {
    $ninjaCommand = Get-Command ninja -ErrorAction SilentlyContinue
    if ($ninjaCommand) {
        $NinjaPath = $ninjaCommand.Source
    } else {
        $cmakeBundle = Split-Path (Split-Path (Split-Path $CMakePath -Parent) -Parent) -Parent
        $candidate = Join-Path $cmakeBundle 'Ninja\ninja.exe'
        if (Test-Path -LiteralPath $candidate) { $NinjaPath = $candidate }
    }
}
if (-not $NinjaPath -or -not (Test-Path -LiteralPath $NinjaPath)) { throw 'ninja was not found' }

$emcmake = if ($emcmakeCommand -is [string]) { $emcmakeCommand } else { $emcmakeCommand.Source }
& $emcmake $CMakePath -S $wasmSource -B $wasmBuild -G Ninja "-DCMAKE_MAKE_PROGRAM=$NinjaPath" -DCMAKE_BUILD_TYPE=Release
if ($LASTEXITCODE -ne 0) { throw 'WASM configure failed' }
& $CMakePath --build $wasmBuild --target ecos --parallel
if ($LASTEXITCODE -ne 0) { throw 'WASM build failed' }

$gcc = (Get-Command gcc -ErrorAction SilentlyContinue).Source
if (-not $gcc) { throw 'gcc is required for the 32-bit-idxint native comparison target' }
& $CMakePath -S $wasmSource -B $nativeBuild -G Ninja "-DCMAKE_MAKE_PROGRAM=$NinjaPath" "-DCMAKE_C_COMPILER=$gcc" -DCMAKE_BUILD_TYPE=Release
if ($LASTEXITCODE -ne 0) { throw 'native comparison configure failed' }
& $CMakePath --build $nativeBuild --target ecos_native_compare --parallel
if ($LASTEXITCODE -ne 0) { throw 'native comparison build failed' }

New-Item -ItemType Directory -Path $distribution -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $wasmBuild 'ecos.js') -Destination (Join-Path $distribution 'ecos.js') -Force
Copy-Item -LiteralPath (Join-Path $wasmBuild 'ecos.wasm') -Destination (Join-Path $distribution 'ecos.wasm') -Force
$env:EMCC = if ($emccCommand -is [string]) { $emccCommand } else { $emccCommand.Source }
node (Join-Path $PSScriptRoot 'write-manifest.mjs')
if ($LASTEXITCODE -ne 0) { throw 'manifest generation failed' }
