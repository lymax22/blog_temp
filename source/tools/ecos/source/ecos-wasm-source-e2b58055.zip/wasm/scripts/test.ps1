param(
    [switch]$SkipBuild,
    [string]$EmsdkRoot = $(if ($env:EMSDK) { $env:EMSDK } else { '' })
)

$ErrorActionPreference = 'Stop'
$repositoryRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
if (-not $SkipBuild) {
    & (Join-Path $PSScriptRoot 'build.ps1') -EmsdkRoot $EmsdkRoot
    if ($LASTEXITCODE -ne 0) { throw 'build failed' }
}
node (Join-Path $repositoryRoot 'wasm\test\run_all.mjs')
if ($LASTEXITCODE -ne 0) { throw 'tests failed' }
