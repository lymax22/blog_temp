import { createHash } from "node:crypto";
import { readFileSync, statSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const repositoryRoot = resolve(fileURLToPath(new URL("../../", import.meta.url)));
const distribution = resolve(repositoryRoot, "dist-wasm");

function command(file, args) {
  return execFileSync(file, args, { cwd: repositoryRoot, encoding: "utf8" }).trim();
}

function describe(name) {
  const path = resolve(distribution, name);
  const data = readFileSync(path);
  return {
    file: name,
    size_bytes: statSync(path).size,
    sha256: createHash("sha256").update(data).digest("hex"),
  };
}

const emcc = process.env.EMCC ?? "emcc";
const emccVersion = command(emcc, ["--version"]).split(/\r?\n/, 1)[0];
const manifest = {
  ecos_version: "2.0.8",
  ecos_header_version: "2.0.10",
  source_commit: command("git", ["rev-parse", "HEAD"]),
  build_type: "wasm",
  compiler: emccVersion,
  emcc_version: emccVersion,
  idxint_bits: 32,
  pfloat_bits: 64,
  exports: ["solveSocp"],
  artifacts: [describe("ecos.js"), describe("ecos.wasm")],
};
writeFileSync(resolve(distribution, "manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`);
console.log(JSON.stringify(manifest, null, 2));
