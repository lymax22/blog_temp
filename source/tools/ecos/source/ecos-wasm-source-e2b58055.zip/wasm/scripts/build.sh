#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
emsdk_root="${EMSDK:-${repo_root}/../_tools/emsdk}"
source "${emsdk_root}/emsdk_env.sh"

emcmake cmake -S "${repo_root}/wasm" -B "${repo_root}/build-wasm/wasm" -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build "${repo_root}/build-wasm/wasm" --target ecos --parallel
cmake -S "${repo_root}/wasm" -B "${repo_root}/build-wasm/native" -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build "${repo_root}/build-wasm/native" --target ecos_native_compare --parallel
mkdir -p "${repo_root}/dist-wasm"
cp "${repo_root}/build-wasm/wasm/ecos.js" "${repo_root}/dist-wasm/ecos.js"
cp "${repo_root}/build-wasm/wasm/ecos.wasm" "${repo_root}/dist-wasm/ecos.wasm"
node "${repo_root}/wasm/scripts/write-manifest.mjs"
