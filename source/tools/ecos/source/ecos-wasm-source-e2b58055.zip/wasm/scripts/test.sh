#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
if [[ "${1:-}" != "--skip-build" ]]; then
  "${repo_root}/wasm/scripts/build.sh"
fi
node "${repo_root}/wasm/test/run_all.mjs"
