import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { existsSync } from "node:fs";
import { resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { solveSocp } from "../js/solver.js";
import { analyticSocp } from "./problems.mjs";
import { infNorm, vectorDifference } from "./test_dual_kkt.mjs";

const repositoryRoot = resolve(fileURLToPath(new URL("../../", import.meta.url)));

export async function runNativeComparison(options = {}) {
  const executable = process.env.ECOS_NATIVE_COMPARE ?? resolve(
    repositoryRoot,
    "build-wasm/native/ecos_native_compare.exe",
  );
  assert.ok(existsSync(executable), `native comparison executable not found: ${executable}`);
  const native = JSON.parse(execFileSync(executable, { encoding: "utf8" }));
  const wasm = await solveSocp(analyticSocp, options);
  const differences = {
    x: infNorm(vectorDifference(wasm.primal.x, native.x)),
    y: infNorm(vectorDifference(wasm.dual.y, native.y)),
    z: infNorm(vectorDifference(wasm.dual.z, native.z)),
    s: infNorm(vectorDifference(wasm.slack.s, native.s)),
  };
  assert.equal(wasm.statusCode, native.statusCode);
  for (const [name, difference] of Object.entries(differences)) {
    assert.ok(difference <= 1e-7, `${name} native/WASM difference ${difference}`);
  }
  for (const name of ["pcost", "dcost", "pres", "dres", "gap"]) {
    assert.ok(Math.abs(wasm.info[name] - native.info[name]) <= 1e-7, `${name} differs`);
  }
  assert.equal(wasm.info.iter, native.info.iter);
  return { native, wasm, differences };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  console.log(JSON.stringify(await runNativeComparison(), null, 2));
}
