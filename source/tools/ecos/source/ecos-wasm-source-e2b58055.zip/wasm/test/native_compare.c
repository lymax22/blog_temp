#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#include "ecos_wasm.h"

static int compare_double(const void* left, const void* right)
{
    const double a = *(const double*)left;
    const double b = *(const double*)right;
    return (a > b) - (a < b);
}

static void print_vector(const double* values, int length)
{
    int i;
    putchar('[');
    for (i = 0; i < length; ++i) {
        if (i > 0) putchar(',');
        printf("%.17g", values[i]);
    }
    putchar(']');
}

static void print_json_number(double value)
{
    if (isfinite(value)) printf("%.17g", value);
    else fputs("null", stdout);
}

int main(void)
{
    const int n = 3, m = 3, p = 2, l = 0, ncones = 1, nex = 0;
    const int q[] = {3};
    const double Gpr[] = {-1.0, -1.0, -1.0};
    const int Gjc[] = {0, 1, 2, 3};
    const int Gir[] = {0, 1, 2};
    const double Apr[] = {1.0, 1.0};
    const int Ajc[] = {0, 0, 1, 2};
    const int Air[] = {0, 1};
    const double c[] = {1.0, 0.0, 0.0};
    const double h[] = {0.0, 0.0, 0.0};
    const double b[] = {3.0, 4.0};
    double x[3], y[2], z[3], s[3], info[ECOS_WASM_INFO_LENGTH];
    int iter = 0;
    int status;
    int sample;
    int repetition;
    double timings[100];

    status = ecos_wasm_solve_once(
        n, m, p, l, ncones, q, nex,
        Gpr, Gjc, Gir, Apr, Ajc, Air, c, h, b,
        x, y, z, s, info, &iter);
    if (status != 0) {
        fprintf(stderr, "Native analytic solve failed with status %d\n", status);
        return 1;
    }

    for (sample = 0; sample < 100; ++sample) {
        const clock_t start = clock();
        int benchmark_status = 0;
        for (repetition = 0; repetition < 100; ++repetition) {
            int benchmark_iter = 0;
            benchmark_status = ecos_wasm_solve_once(
                n, m, p, l, ncones, q, nex,
                Gpr, Gjc, Gir, Apr, Ajc, Air, c, h, b,
                x, y, z, s, info, &benchmark_iter);
            if (benchmark_status != 0) return 2;
        }
        const clock_t stop = clock();
        timings[sample] = 10.0 * (double)(stop - start) / (double)CLOCKS_PER_SEC;
    }
    qsort(timings, 100, sizeof(double), compare_double);

    printf("{\"statusCode\":%d,\"x\":", status); print_vector(x, n);
    printf(",\"y\":"); print_vector(y, p);
    printf(",\"z\":"); print_vector(z, m);
    printf(",\"s\":"); print_vector(s, m);
    printf(",\"info\":{\"pcost\":"); print_json_number(info[0]);
    printf(",\"dcost\":"); print_json_number(info[1]);
    printf(",\"pres\":"); print_json_number(info[2]);
    printf(",\"dres\":"); print_json_number(info[3]);
    printf(",\"gap\":"); print_json_number(info[4]);
    printf(",\"relgap\":"); print_json_number(info[5]);
    printf(",\"pinfres\":"); print_json_number(info[6]);
    printf(",\"dinfres\":"); print_json_number(info[7]);
    printf(",\"iter\":%d}", iter);
    printf(",\"nativeMedianMs\":%.9g}\n", 0.5 * (timings[49] + timings[50]));
    return 0;
}
