import assert from "node:assert/strict";
import { pathToFileURL } from "node:url";
import { solveSocp } from "../js/solver.js";
import { infeasibleLp, noEqualitySocp, positiveOrthantLp } from "./problems.mjs";

function close(actual, expected, tolerance, label) {
  assert.ok(Math.abs(actual - expected) <= tolerance, `${label}: ${actual} vs ${expected}`);
}

export async function runBasicTests(options = {}) {
  const lp = await solveSocp(positiveOrthantLp, options);
  assert.equal(lp.status, "optimal");
  close(lp.primal.x[0], 1, 1e-7, "LP x");
  close(lp.dual.z[0], 1, 1e-7, "LP z");
  assert.equal(lp.dual.y.length, 0);

  const socp = await solveSocp(noEqualitySocp, options);
  assert.equal(socp.status, "optimal");
  close(socp.primal.x[0], 1, 1e-7, "no-equality SOCP x");
  assert.equal(socp.dual.y.length, 0);

  const infeasible = await solveSocp(infeasibleLp, options);
  assert.ok(
    infeasible.status === "primal_infeasible" || infeasible.status === "primal_infeasible_inaccurate",
    `expected primal infeasibility, got ${infeasible.status}`,
  );

  await assert.rejects(
    () => solveSocp({ ...positiveOrthantLp, h: [Number.NaN] }, options),
    /must be finite/,
  );
  await assert.rejects(
    () => solveSocp({ ...positiveOrthantLp, c: [Number.POSITIVE_INFINITY] }, options),
    /must be finite/,
  );
  await assert.rejects(
    () => solveSocp({ ...positiveOrthantLp, G: [[-1, 0]] }, options),
    /must contain 1 columns/,
  );
  await assert.rejects(
    () => solveSocp({ ...positiveOrthantLp, cones: { l: 2, q: [], nex: 0 } }, options),
    /must equal/,
  );
  await assert.rejects(
    () => solveSocp({
      ...positiveOrthantLp,
      G: { rows: 1, cols: 1, values: [-1], colPointers: [0, 2], rowIndices: [0] },
    }, options),
    /must start at 0 and end at values.length/,
  );
  await assert.rejects(
    () => solveSocp({
      c: [1, 0, 0],
      G: {
        rows: 3, cols: 3, values: [-1, -1, -1],
        colPointers: [0, 2, 1, 3], rowIndices: [0, 1, 2],
      },
      h: [0, 0, 0], b: [], cones: { l: 0, q: [3], nex: 0 },
    }, options),
    /must be monotonic/,
  );
  await assert.rejects(
    () => solveSocp({
      ...positiveOrthantLp,
      G: { rows: 1, cols: 1, values: [-1], colPointers: [0, 1], rowIndices: [1] },
    }, options),
    /outside/,
  );
  return { lp, noEqualitySocp: socp, infeasible };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  await runBasicTests();
  console.log("basic tests: PASS");
}
