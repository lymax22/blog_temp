import assert from "node:assert/strict";
import { performance } from "node:perf_hooks";
import { getEcosModule, solveSocp } from "../js/solver.js";
import { analyticSocp } from "./problems.mjs";
import { runBasicTests } from "./test_basic.mjs";
import { runDualKktTest } from "./test_dual_kkt.mjs";
import { runNativeComparison } from "./test_native_vs_wasm.mjs";

const Module = await getEcosModule();
const options = { module: Module };

const firstStart = performance.now();
await solveSocp(analyticSocp, options);
const firstCallMs = performance.now() - firstStart;
const heapBefore = Module.HEAPU8.buffer.byteLength;
const timings = [];
let stableResult;
for (let i = 0; i < 100; i += 1) {
  const start = performance.now();
  stableResult = await solveSocp(analyticSocp, options);
  timings.push(performance.now() - start);
}
const heapAfter = Module.HEAPU8.buffer.byteLength;
assert.equal(heapAfter, heapBefore, `WASM heap grew from ${heapBefore} to ${heapAfter}`);
assert.equal(stableResult.status, "optimal");

const basic = await runBasicTests(options);
const analytic = await runDualKktTest(options);
const comparison = await runNativeComparison(options);
timings.sort((a, b) => a - b);
const warmMedianMs = 0.5 * (timings[49] + timings[50]);

console.log(JSON.stringify({
  classifications: {
    WASM_BUILD_PASS: true,
    DUAL_KKT_PASS: true,
    NATIVE_WASM_EQUIVALENCE_PASS: true,
    MEMORY_LOOP_PASS: true,
    LP_TEST_PASS: basic.lp.status === "optimal",
    NO_EQUALITY_SOCP_PASS: basic.noEqualitySocp.status === "optimal",
    INFEASIBLE_STATUS_TEST_PASS: basic.infeasible.status.startsWith("primal_infeasible"),
  },
  analytic,
  nativeComparison: comparison,
  memory: { solves: 100, heapBefore, heapAfter },
  performance: {
    wasmFirstCallMs: firstCallMs,
    wasmWarmMedianMs: warmMedianMs,
    nativeMedianMs: comparison.native.nativeMedianMs,
  },
}, null, 2));
