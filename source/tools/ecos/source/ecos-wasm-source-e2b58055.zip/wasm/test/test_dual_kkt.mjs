import assert from "node:assert/strict";
import { pathToFileURL } from "node:url";
import { solveSocp } from "../js/solver.js";
import { analyticSocp } from "./problems.mjs";

export function infNorm(values) {
  return values.reduce((maximum, value) => Math.max(maximum, Math.abs(value)), 0);
}

export function vectorDifference(left, right) {
  assert.equal(left.length, right.length);
  return left.map((value, index) => value - right[index]);
}

function multiply(matrix, vector) {
  return matrix.map((row) => row.reduce((sum, value, index) => sum + value * vector[index], 0));
}

function transposeMultiply(matrix, vector) {
  const result = new Array(matrix[0].length).fill(0);
  for (let row = 0; row < matrix.length; row += 1) {
    for (let col = 0; col < matrix[row].length; col += 1) result[col] += matrix[row][col] * vector[row];
  }
  return result;
}

function dot(left, right) {
  return left.reduce((sum, value, index) => sum + value * right[index], 0);
}

function socViolation(vector) {
  return Math.max(0, Math.hypot(...vector.slice(1)) - vector[0]);
}

export function independentKkt(result) {
  const { x } = result.primal;
  const { y, z } = result.dual;
  const { s } = result.slack;
  const equality = vectorDifference(multiply(analyticSocp.A, x), analyticSocp.b);
  const coneAffine = vectorDifference(
    multiply(analyticSocp.G, x).map((value, index) => value + s[index]),
    analyticSocp.h,
  );
  const aty = transposeMultiply(analyticSocp.A, y);
  const gtz = transposeMultiply(analyticSocp.G, z);
  const stationarity = analyticSocp.c.map((value, index) => value + aty[index] + gtz[index]);
  return {
    equalityInf: infNorm(equality),
    coneAffineInf: infNorm(coneAffine),
    stationarityInf: infNorm(stationarity),
    complementarity: dot(s, z),
    coneSViolation: socViolation(s),
    coneZViolation: socViolation(z),
    primalObjective: dot(analyticSocp.c, x),
    dualObjective: -(dot(analyticSocp.b, y) + dot(analyticSocp.h, z)),
  };
}

export async function runDualKktTest(options = {}) {
  const result = await solveSocp(analyticSocp, options);
  assert.equal(result.status, "optimal");
  const expected = {
    x: [5, 3, 4],
    y: [-3 / 5, -4 / 5],
    z: [1, -3 / 5, -4 / 5],
    s: [5, 3, 4],
  };
  assert.ok(infNorm(vectorDifference(result.primal.x, expected.x)) <= 1e-6, "analytic x tolerance");
  assert.ok(infNorm(vectorDifference(result.dual.y, expected.y)) <= 1e-6, "analytic y tolerance");
  assert.ok(infNorm(vectorDifference(result.dual.z, expected.z)) <= 1e-6, "analytic z tolerance");
  assert.ok(infNorm(vectorDifference(result.slack.s, expected.s)) <= 1e-6, "analytic s tolerance");

  const kkt = independentKkt(result);
  assert.ok(kkt.equalityInf <= 1e-7, `equality residual ${kkt.equalityInf}`);
  assert.ok(kkt.coneAffineInf <= 1e-7, `cone affine residual ${kkt.coneAffineInf}`);
  assert.ok(kkt.stationarityInf <= 1e-7, `stationarity residual ${kkt.stationarityInf}`);
  assert.ok(Math.abs(kkt.complementarity) <= 1e-7, `complementarity ${kkt.complementarity}`);
  assert.ok(kkt.coneSViolation <= 1e-7, `primal cone violation ${kkt.coneSViolation}`);
  assert.ok(kkt.coneZViolation <= 1e-7, `dual cone violation ${kkt.coneZViolation}`);
  return { result, expected, kkt };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const output = await runDualKktTest();
  console.log(JSON.stringify(output, null, 2));
}
