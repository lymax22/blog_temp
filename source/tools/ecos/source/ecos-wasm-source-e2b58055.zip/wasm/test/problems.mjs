export const analyticSocp = {
  c: [1, 0, 0],
  G: [
    [-1, 0, 0],
    [0, -1, 0],
    [0, 0, -1],
  ],
  h: [0, 0, 0],
  A: [
    [0, 1, 0],
    [0, 0, 1],
  ],
  b: [3, 4],
  cones: { l: 0, q: [3], nex: 0 },
};

export const positiveOrthantLp = {
  c: [1],
  G: [[-1]],
  h: [-1],
  b: [],
  cones: { l: 1, q: [], nex: 0 },
};

export const noEqualitySocp = {
  c: [1],
  G: [[-1], [0], [0]],
  h: [0, 1, 0],
  b: [],
  cones: { l: 0, q: [3], nex: 0 },
};

export const infeasibleLp = {
  c: [0],
  G: [[-1], [1]],
  h: [-1, 0],
  b: [],
  cones: { l: 2, q: [], nex: 0 },
};
