/*
 * ECOS - Embedded Conic Solver.
 * Copyright (C) 2012-2015 A. Domahidi [domahidi@embotech.com],
 * Automatic Control Lab, ETH Zurich & embotech GmbH, Zurich, Switzerland.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


/* main file with example of how to run ECOS */

#include <stdio.h>

#include "ecos.h"
//#include "data.h"
#include <stdlib.h>
#include "sq_norm.h"
#include "qcml_utils.h"
static double read_one(FILE* fp) {
    double x;
    if (fscanf_s(fp, "%lf", &x) != 1) {
        fprintf(stderr, "Unexpected EOF or parse error\n");
        exit(1);
    }
    return x;
}

static void read_array_pfloat(FILE* fp, pfloat* a, size_t n) {
    for (size_t k = 0; k < n; ++k) a[k] = (pfloat)read_one(fp);
}

static void read_array_idxint(FILE* fp, idxint* a, size_t n) {
    for (size_t k = 0; k < n; ++k) a[k] = (idxint)read_one(fp);
}

qc_socp* test_data_process()
{
    FILE* fp = fopen("D:\\working\\conf\\Convert\\data.dat", "r");
    if (!fp) { perror("open"); return 1; }
    /* allocate socp data structure */
    qc_socp* data = (qc_socp*)calloc(1, sizeof(qc_socp));
    if (!data) return qc_socp_free(data);

    //'n', 'm', 'p', 'l', 'ncones', 'c', 'h', 'q', 'Gjc', 'Gir', 'Gpr', 'Ajc', 'Air', 'Apr', 'b'
    // 1) �ȶ�������ע�⣺�� -ascii ���������� double����Ҫ��ת�� int��
    data->n = (idxint)read_one(fp);
    data->m = (idxint)read_one(fp);
    data->p = (idxint)read_one(fp);
    data->l = (idxint)read_one(fp);
    data->nsoc = (idxint)read_one(fp);

    //// 2) ������/���飺�����֪�����ǳ���
    ////    ���ﳤ�����޷�����£���Ҫ���� n/m/p/... �Ƴ���

    //// �������� c ����Ϊ 1126
    data->c = (pfloat*)calloc(data->n, sizeof(pfloat));
    //pfloat *c = (pfloat*)malloc(sizeof(pfloat) * n);
    read_array_pfloat(fp, data->c, data->n);

    //// �������� h ����Ϊ 1791
    data->h = (pfloat*)calloc(data->m, sizeof(pfloat));
    //pfloat *h = (pfloat*)malloc(sizeof(pfloat) * m);
    read_array_pfloat(fp, data->h, data->m);

    data->q = (idxint*)calloc(data->nsoc, sizeof(idxint));
    //idxint *q = (idxint*)malloc(sizeof(idxint) * 104);
    read_array_idxint(fp, data->q, data->nsoc);

    idxint nnzA = 0, nnzG = 0;

    nnzG = (idxint)read_one(fp);
    nnzA = (idxint)read_one(fp);

    ///*��matlab�У�����������1��ʼ����c������Ҫ��0��ʼ*/
    data->Gp = (idxint*)calloc(nnzG, sizeof(idxint));
    //idxint *Gjc = (idxint*)malloc(sizeof(idxint) * 1842);
    read_array_idxint(fp, data->Gp, nnzG);

    data->Gi = (idxint*)calloc(nnzG, sizeof(idxint));
    //idxint *Gir = (idxint*)malloc(sizeof(idxint) * 1842);
    read_array_idxint(fp, data->Gi, nnzG);

    data->Gx = (pfloat*)calloc(nnzG, sizeof(pfloat));
    //pfloat *Gpr = (pfloat*)malloc(sizeof(pfloat) * 1842);
    read_array_pfloat(fp, data->Gx, nnzG);

    data->Ap = (idxint*)calloc(nnzA, sizeof(idxint));
    //idxint *Ajc = (idxint*)malloc(sizeof(idxint) * 5793);
    read_array_idxint(fp, data->Ap, nnzA);

    data->Ai = (idxint*)calloc(nnzA, sizeof(idxint));
    //idxint *Air = (idxint*)malloc(sizeof(idxint) * 5793);
    read_array_idxint(fp, data->Ai, nnzA);

    data->Ax = (pfloat*)calloc(nnzA, sizeof(pfloat));
    //pfloat *Apr = (pfloat*)malloc(sizeof(pfloat) * 5793);
    read_array_pfloat(fp, data->Ax, nnzA);

    data->b = (pfloat*)calloc(data->p, sizeof(pfloat));
    //pfloat *b = (pfloat*)malloc(sizeof(pfloat) * p);
    read_array_pfloat(fp, data->b, data->p);

    fclose(fp);

    qc_matrix* G_csc;
    qc_matrix G_coo;
    /* convert G and A ptrs into a qc_matrix */
    G_coo.m = data->m; G_coo.n = data->n; G_coo.nnz = nnzG;
    G_coo.i = data->Gi;
    G_coo.j = data->Gp;
    G_coo.v = data->Gx;

    /* convert the matrices to column compressed form */
    G_csc = qc_compress(&G_coo);
    
    /* free memory used for COO matrix, so it can be reassigned later */
    free(data->Gi);
    free(data->Gp);
    free(data->Gx);
    /* reassign into data, pointer now owned by data */
    data->Gi = G_csc->i;
    data->Gp = G_csc->j;
    data->Gx = G_csc->v;
    /* only free temp CSC pointer, but not its data */
    free(G_csc);

    qc_matrix* A_csc;
    qc_matrix A_coo;

    A_coo.m = data->p; A_coo.n = data->n; A_coo.nnz = nnzA;
    A_coo.i = data->Ai;
    A_coo.j = data->Ap;
    A_coo.v = data->Ax;

    ///* convert the matrices to column compressed form */
    A_csc = qc_compress(&A_coo);

    ///* free memory used for COO matrix, so it can be reassigned later */
    free(data->Ai);
    free(data->Ap);
    free(data->Ax);
    ///* reassign into data, pointer now owned by data */
    data->Ai = A_csc->i;
    data->Ap = A_csc->j;
    data->Ax = A_csc->v;
    ///* only free temp CSC pointer, but not its data */
    free(A_csc);

    return data;
}


int main(void)
{
    ///*for test*/
    //idxint n = 3;
    //idxint m = 3;
    //idxint p = 3;
    //idxint l = 0;
    //idxint ncones = 1;
    //idxint q[] = {3};
    //pfloat c[] = {-1, 0, 0};
    //pfloat h[] = {0, 0, 0};
    //pfloat b[] = {1, 0, 0};
    //qc_matrix* G_csc;
    //qc_matrix G_coo;
    //qc_matrix* A_csc;
    //qc_matrix A_coo;

    //idxint Gir[] = { 1, 2, 0};
    //idxint Gjc[] = { 1, 2, 0};
    //pfloat Gpr[] = { -1, -1 ,-1};

    //G_coo.m = 3; G_coo.n = 3; G_coo.nnz = 3;
    //G_coo.i = Gir;
    //G_coo.j = Gjc;
    //G_coo.v = Gpr;
    //G_csc = qc_compress(&G_coo);

    //idxint Air[] = { 0, 1, 1, 2};
    //idxint Ajc[] = { 0, 1, 2, 2};
    //pfloat Apr[] = { 1, 1, 1, 2};

    //A_coo.m = 3; A_coo.n = 3; A_coo.nnz = 4;
    //A_coo.i = Air;
    //A_coo.j = Ajc;
    //A_coo.v = Apr;
    //A_csc = qc_compress(&A_coo);
   
    qc_socp* data;

    data = test_data_process();
    /*data = qc_sq_norm2socp();*/

    idxint exitflag = ECOS_FATAL;
	pwork* mywork;
#if PROFILING > 1 && PRINTLEVEL > 2
    double torder, tkktcreate, ttranspose, tfactor, tkktsolve, ttotal, tsetup, tsolve;
#endif
	
	/* set up data (for test)*/	
    //mywork = ECOS_setup(data->n, data->m, data->p,
    //    data->l, data->nsoc, data->q, 0,
    //    data->Gx, data->Gp, data->Gi,
    //    data->Ax, data->Ap, data->Ai,
    //    data->c, data->h, data->b);

    mywork = ECOS_setup(data->n, data->m, data->p,
        data->l, data->nsoc, data->q, 0,
        data->Gx, data->Gp, data->Gi,
        data->Ax, data->Ap, data->Ai,
        data->c, data->h, data->b);
 
    //mywork = ECOS_setup(n, m, p, l, ncones, q, 0, Gpr, Gjc, Gir, Apr, Ajc, Air, c, h, b);

    if( mywork != NULL ){
	
		/* solve */	
		exitflag = ECOS_solve(mywork);
    
    	/* test second solve
    	exitflag = ECOS_solve(mywork); */

#if PROFILING > 1 && PRINTLEVEL > 2
		
		/* some statistics in milliseconds */
		tsolve = mywork->info->tsolve         * 1000;
		tsetup = mywork->info->tsetup         * 1000;
		ttotal = tsetup + tsolve;
	
		torder = mywork->info->torder         * 1000;
		tkktcreate = mywork->info->tkktcreate * 1000;
		ttranspose = mywork->info->ttranspose * 1000;
		tfactor = mywork->info->tfactor       * 1000;
		tkktsolve = mywork->info->tkktsolve   * 1000;
	
		printf("ECOS timings (all times in milliseconds):\n\n");
		printf("1. Setup: %7.3f (%4.1f%%)\n", tsetup,  tsetup / ttotal*100);
		printf("2. Solve: %7.3f (%4.1f%%)\n", tsolve,  tsolve / ttotal*100);
		printf("----------------------------------\n");
		printf(" Total solve time: %7.3f ms\n\n", ttotal);
	
		printf("Detailed timings in SETUP:\n");
		printf("Create transposes: %7.3f (%4.1f%%)\n", ttranspose, ttranspose / tsetup*100);
		printf("Create KKT Matrix: %7.3f (%4.1f%%)\n", tkktcreate, tkktcreate / tsetup*100);
		printf(" Compute ordering: %7.3f (%4.1f%%)\n", torder,         torder / tsetup*100);
		printf("            Other: %7.3f (%4.1f%%)\n", tsetup-torder-tkktcreate-ttranspose,         (tsetup-torder-tkktcreate-ttranspose) / tsetup*100);
		printf("\n");

		printf("Detailed timings in SOLVE:\n");
		printf("   Factorizations: %7.3f (%4.1f%% of tsolve / %4.1f%% of ttotal)\n", tfactor,     tfactor / tsolve*100, tfactor / ttotal*100);
		printf("       KKT solves: %7.3f (%4.1f%% of tsolve / %4.1f%% of ttotal)\n", tkktsolve, tkktsolve / tsolve*100, tfactor / ttotal*100);
		printf("            Other: %7.3f (%4.1f%% of tsolve / %4.1f%% of ttotal)\n", tsolve-tkktsolve-tfactor, (tsolve-tkktsolve-tfactor) / tsolve*100, (tsolve-tkktsolve-tfactor) / ttotal*100);
		printf("\n");
#endif
	
    	/* clean up memory */
		ECOS_cleanup(mywork, 0);
        
    }
    
    /* test version number
    ECOS_ver(ver);
    printf("This test has been run on ECOS version %s\n", ver);
     */
	
    /* explicitly truncate exit code */
	return (int)exitflag;
}
